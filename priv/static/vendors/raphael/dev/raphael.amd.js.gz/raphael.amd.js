define(["./raphael.core", "./raphael.svg", "./raphael.vml"], function(R) {

    return R;

});