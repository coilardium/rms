$(function () {
  eval($('#code').text());
  prettyPrint();
});