export var defaultInvalidDate = 'Invalid date';

export function invalidDate () {
    return this._invalidDate;
}
