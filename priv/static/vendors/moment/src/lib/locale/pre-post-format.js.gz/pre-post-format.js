export function preParsePostFormat (string) {
    return string;
}
