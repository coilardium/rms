import { createDuration } from './create';

export function clone () {
    return createDuration(this);
}

